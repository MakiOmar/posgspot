<?php

 return [
     'units' => 'الوحدات',
     'manage_your_units' => 'إدارة الوحدات الخاصة بك',
     'all_your_units' => 'كل الوحدات الخاصة بك',
     'name' => 'الإسم',
     'short_name' => 'اسم مختصر',
     'allow_decimal' => 'سماح استخدام الكسور',
     'added_success' => 'تمت إضافة الوحدة بنجاح',
     'updated_success' => 'تم تحديث الوحدة بنجاح',
     'deleted_success' => 'تم حذف الوحدة بنجاح',
     'add_unit' => 'إضافة وحدة',
     'edit_unit' => 'تعديل وحدة',
 ];
