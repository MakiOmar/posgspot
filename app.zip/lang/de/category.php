<?php

 return [
     'categories' => 'Kategorien',
     'manage_your_categories' => 'Verwalten Sie Ihre Kategorien',
     'all_your_categories' => 'Alle deine Kategorien',
     'category' => 'Kategorie',
     'category_name' => 'Kategoriename',
     'code' => 'Kategoriecode',
     'add_as_sub_category' => 'Als Unterkategorie hinzufügen',
     'select_parent_category' => 'Wählen Sie die übergeordnete Kategorie',
     'added_success' => 'Kategorie erfolgreich hinzugefügt',
     'updated_success' => 'Kategorie erfolgreich aktualisiert',
     'deleted_success' => 'Kategorie erfolgreich gelöscht',
     'add_category' => 'Kategorie hinzufügen',
     'edit_category' => 'Kategorie bearbeiten',
 ];
