<?php

 return [
     'units' => 'Uniddes',
     'manage_your_units' => 'Gerenciar suas unidades',
     'all_your_units' => 'Todas as suas unidades',
     'name' => 'Nome',
     'short_name' => 'Nome abreviado',
     'allow_decimal' => 'Permitir decimal',
     'added_success' => 'Unidade adicionada com sucesso',
     'updated_success' => 'Unidade atualizada com sucesso',
     'deleted_success' => 'Drive excluído com sucesso',
     'add_unit' => 'Adicionar unidade',
     'edit_unit' => 'Editar unidade',
 ];
