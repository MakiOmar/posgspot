export type Language = 'en' | 'ar';
export type Environment = 'production' | 'sandbox';
export type Region = 'egypt' | 'ksa' | 'uae';
export interface StartWithConfigOptions {
    sessionId: string;
    merchantId?: string;
    merchantName?: string;
    environment?: Environment;
    language?: Language;
    region?: Region;
    primaryColor?: string;
    secondaryColor?: string;
}
export interface PaymentMethod {
    type?: string;
    brand?: string;
    maskedCardNumber?: string;
    cardholderName?: string;
    wallet?: string;
    expiryDate?: {
        month: number;
        year: number;
    };
}
export interface PaymentResult {
    orderId?: string;
    tokenId?: string;
    agreementId?: string;
    paymentMethod?: PaymentMethod;
}
export interface GeideaResult {
    status: 'completed' | 'canceled';
    result?: PaymentResult;
}
