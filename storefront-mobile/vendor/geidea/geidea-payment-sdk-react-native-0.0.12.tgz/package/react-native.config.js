module.exports = {
  dependency: {
    platforms: {
      ios: {},
      android: {
        sourceDir: './android',
        packageImportPath: 'import com.geideaintegration.GeideaBridgePackage;',
        packageInstance: 'new GeideaBridgePackage()',
      },
    },
  },
};
